

import java.util.Iterator;
import java.util.NoSuchElementException;


public class Deque<Item> implements Iterable<Item> {
    private Node<Item> first;    // beginning of queue
    private Node<Item> last;     // end of queue
    private int size;               // number of elements on queue

    // helper linked list class
    private static class Node<Item> {
        private Item item;
        private Node<Item> next; // next item towards the front
        private Node<Item> pre;	// next item towards the end
    }

	public Deque() {
		first = null;
		last = null;
		size = 0;
	}
	
	private void checkRep(){
		assert first == null ? last == null : last != null;
	}
	
	public boolean isEmpty() {
		return first == null || last == null;
	}
	
	public int size(){
		return size;
	}
	
	public void addFirst(Item item){
		if(item == null){
			throw new NullPointerException("Cannot add null item!");
		}
		Node<Item> oldFirst = first;
		first = new Node<>();
		first.item = item;
		first.next = null;
		first.pre = oldFirst;
		if (isEmpty()) 	last = first;
		else			oldFirst.next = first;
		size ++;
		checkRep();
	}
	
	public void addLast(Item item) {
		if(item == null){
			throw new NullPointerException("Cannot add null item!");
		}
		Node<Item> oldLast = last;
		last = new Node<>();
		last.pre = null;
		last.next = oldLast;
		last.item = item;
		if (isEmpty())	first = last;
		else oldLast.pre = last;
		size ++;
		checkRep();
	}
	
	public Item removeFirst() {
		if(isEmpty()) throw new NoSuchElementException("Deque underflow");
		Item item = first.item;
		first = first.pre;
		size --;
		
		if(isEmpty()) last = null;
		else first.next = null;
		checkRep();
		return item;
	}
	
	public Item removeLast() {
		if(isEmpty()) throw new NoSuchElementException("Deque underflow");
		Item item = last.item;
		last = last.next;
		size --;
		
		// last may now be null or a Node
		if(isEmpty()) first = null;
		else last.pre = null;
		checkRep();
		return item;
	}
	
	@Override
	public Iterator<Item> iterator() {
		return new ListIterator<Item>(first);
	}
	
    private class ListIterator<I> implements Iterator<I> {
		private Node<I> current;
		public ListIterator(Node<I> first) {
			current = first;
		}
		@Override
		public boolean hasNext() {
			return current != null;
		}
		@Override
		public I next() {
			if (!hasNext()) throw new NoSuchElementException();
			I item = current.item;
			current = current.pre;
			return item;
		}
		public void remove() { throw new UnsupportedOperationException();}
	}
	
	public static void main(String[] args){
		Deque<String> deque = new Deque<>();
		deque.addFirst("a");
		deque.addFirst("b");
		deque.addLast("c");
		System.out.println("removing last:" +  deque.removeLast());
		System.out.println("removing last:" +  deque.removeLast());
		System.out.println("removing last:" +  deque.removeLast());
		deque.addFirst("a");
		deque.addLast("z");
		System.out.println("removing first:" + deque.removeFirst());
		
		System.out.println("\n\nPrinting dequeue...");
		for(String item : deque){
			System.out.println(item);
		}
		System.out.println(deque.isEmpty());
	}
}


































